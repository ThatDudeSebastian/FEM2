function  postprocessing(time, tdm, ndm, elem, x, drltValue, drltDofs, fsur, neumDofs, u)

%----------------------------------------------------------------------
% volume average of state variables
%----------------------------------------------------------------------
nel = length(elem);
[nqp,nsv] = size(elem(1).stateVar);

celldata = repmat(struct('stateVar', zeros(1,nsv)), nel,1);

for e = 1:nel
    % deformed volume of ethe lement
    v = 0;
    for q = 1:nqp
        v = v + elem(e).dv(q);
    end;
    % average 
    for q = 1:nqp
        celldata(e).stateVar = celldata(e).stateVar + elem(e).stateVar(q,:) * elem(e).dv(q);
    end;
    celldata(e).stateVar = celldata(e).stateVar / v;
end;


%=========================================================================
% post-processing - visualising results
%=========================================================================

scale_factor = 1;
% SIG, EPS, ALPHA, EPS_P
% nsv = 2*tdm*tdm + 1 + tdm*tdm;

figure(1);
clf;
for e=1:nel
    nen = length(elem(e).cn);
    xe = zeros(ndm, nen);
    for idm = 1:ndm
        xe(idm,:) = x(elem(e).cn,idm);
    end
    
    % dofs belonging to element e
    edof = zeros(ndm, nen);
    for ien=1:nen
       for idm=1:ndm
           edof(idm,ien) = ndm*elem(e).cn(ien)+idm-ndm;
       end
    end
    ue = u(edof);
        
    deformed = xe + scale_factor * ue;
    
    % extract stress and strain tensor
    sig = reshape(celldata(e).stateVar(1:tdm*tdm), [tdm,tdm,1]);
    eps = reshape(celldata(e).stateVar(tdm*tdm+1:2*tdm*tdm), [tdm,tdm,1]);
    
    % extract alpha and epp(i,j) 
    jsv = 2*tdm*tdm+1;
    alpha = celldata(e).stateVar(jsv);
    % plastic strain
    epsp = reshape(celldata(e).stateVar(jsv+1:jsv+tdm*tdm), [tdm,tdm,1]);
    
    patch(deformed(1,:), deformed(2,:), sig(2,2))
    hold on
end
title('\sigma_{22}');
caxis([0 410]);
h = colorbar;
%set(h, 'YLim', [-150, 150]);

axis equal;
hold off
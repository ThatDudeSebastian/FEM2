function  [C4] = Hooke(matparam)

% Material parameter
xE   = matparam(1);        % Young's modulus
xnu  = matparam(2);        % Poisson ratio

xblk = xE / (3*(1 - 2*xnu));   % bulk modulus
xmu =  xE / (2*(1 + xnu));     % shear modulus = second Lame parameter

C4=zeros(2,2,2,2);
C4(1,1,1,1)= #TODO
end

function [ndm,ndf,nnp,nel,nen,x,elem,matparam,drlt,neum,b] = input_circle()

N = load("circle_n.msh");
x = [N(:,2), N(:,3)];


% Number of node points and number of spatial dimensions
[nnp, ndm] = size(x);

% Number of degrees of freedom per node
ndf = ndm;  % mechanical analysis
 
E = load("circle_e.msh");
connectivity = E(:, 2:end);
 

% Number of elements and number of nodes per element
[nel,nen] = size(connectivity);

clf
hold on

% Organize connectivity list as a struct
elem = repmat( struct('cn',zeros(1,nen)), nel,1);
for e = 1:nel
    elem(e).cn = connectivity(e,:);
    
    plot(x(connectivity(e,:), 1), x(connectivity(e,:), 2), 'x-', 'color', [0.7, 0.7, 0.7], 'linewidth', 1)
    #drawnow
    #pause(0.2)
end;

% Young's modulus
matparam(1) = 210E9;
% Poisson ratio
matparam(2) = 0.3;
% yield stress initial
matparam(3) = 100;
% hardening modul linear
matparam(4) = 700;
% density 
matparam(5) = 2.7e-03;



% boundary conditions
% only homogeneous Dirichlet boundary conditions are allowed!
% Dirichlet boundary condition
%      node     ldof      scale
##drlt = [ ...
##         38      2      0.0; ...
##         38      1      0.0; ...
##         33      2      0.0; ...
##         33      1      0.0; ...
##         41      2      0.0; ...
##         41      1      0.0; ...
##   ];


drlt = [ ...
         549      2      0.0; ...
         549      1      0.0; ...
         547      2      0.0; ...
         547      1      0.0; ...
         551      2      0.0; ...
         551      1      0.0; ...
   ];

   plot(x(drlt(:,1), 1), x(drlt(:,1), 2), 'go')
   
% Neumann boundary condition
%      node  ldof  value
##neum = [  20  2  1;
##          ];
          
neum = [  213  2   1 ;
          227  2   1 ;
          242  2   1 ;
          253  2   1 ; 
          259  2   1 ;
          260  2   1 ;
          254  2   1 ;
          245  2   1 ;
          233  2   1 ;
          218  2   1 ;
          200  2   1 ;
          ];

  for i = 1:size(neum, 1)
    neum(i, 3) = 5E6 * sin(pi*(i-1)/(size(neum,1)-1));
  endfor
  
  %neum
          
  plot(x(neum(:,1), 1), x(neum(:,1), 2), 'ro')
          
% Body force aka gravity
b = [0; ...
     0];
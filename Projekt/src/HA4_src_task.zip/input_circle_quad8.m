function [ndm,ndf,nnp,nel,nen,x,elem,matparam,drlt,neum,b] = input_circle_quad8()

N = load("circle8_n.msh");
x = [N(:,2), N(:,3)];


% Number of node points and number of spatial dimensions
[nnp, ndm] = size(x);

% Number of degrees of freedom per node
ndf = ndm;  % mechanical analysis
 
E = load("circle8_e.msh");
connectivity = E(:, 2:end);
 

% Number of elements and number of nodes per element
[nel,nen] = size(connectivity);

clf
hold on

% Organize connectivity list as a struct
elem = repmat( struct('cn',zeros(1,nen)), nel,1);
for e = 1:nel
    elem(e).cn = connectivity(e,:);
  
    plot([x(connectivity(e,1:4), 1); x(connectivity(e,1), 1)], [x(connectivity(e,1:4), 2); x(connectivity(e,1), 2)], 'x-', 'color', [0.6, 0.6, 0.6], 'linewidth', 1)
    plot(x(connectivity(e,5:8), 1), x(connectivity(e,5:8), 2), 'x', 'color', [0.7, 0.8, 0.7], 'linewidth', 1)
    #drawnow
    #pause(0.2)
end;

% Young's modulus
matparam(1) = 210E9;
% Poisson ratio
matparam(2) = 0.3;
% yield stress initial
matparam(3) = 100;
% hardening modul linear
matparam(4) = 700;
% density 
matparam(5) = 2.7e-03;



% boundary conditions
% only homogeneous Dirichlet boundary conditions are allowed!
% Dirichlet boundary condition
%      node     ldof      scale
##drlt = [ ...
##         38      2      0.0; ...
##         38      1      0.0; ...
##         33      2      0.0; ...
##         33      1      0.0; ...
##         41      2      0.0; ...
##         41      1      0.0; ...
##   ];


drlt = [ ...
         1592      2      0.0; ...
         1592      1      0.0; ...
         1590     2      0.0; ...
         1590      1      0.0; ...
         1594      2      0.0; ...
         1594      1      0.0; ...
   ];

   plot(x(drlt(:,1), 1), x(drlt(:,1), 2), 'go')
   
% Neumann boundary condition
%      node  ldof  value
##neum = [  20  2  1;
##          ];
          
neum = [  611  2   1 ;
          634  2   1 ;
          656  2   1 ;
          675  2   1 ; 
          692  2   1 ;
          707  2   1 ;
          722  2   1 ;
          730  2   1 ;
          746  2   1 ;
          750  2   1 ;
          749  2   1 ;
          743  2   1 ;
          729  2   1 ;
          720  2   1 ;
          704  2   1 ; 
          687  2   1 ;
          672  2   1 ;
          652  2   1 ;
          629  2   1 ;
          606  2   1 ;
          582  2   1 ;
          ];

  for i = 1:size(neum, 1)
    neum(i, 3) = 5E6 * sin(pi*(i-1)/(size(neum,1)-1));
  endfor
  
  %neum
          
  plot(x(neum(:,1), 1), x(neum(:,1), 2), 'ro')
          
% Body force aka gravity
b = [0; ...
     0];
     
drawnow
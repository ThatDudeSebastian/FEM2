#TODO: This is a template for a 2D/ 3D material model.
#The homework requires to implement a plastic model!
#Still, for testing purposes, one could start with completing this
#template for the purely elastic model and then extending it in a new file
function  [sigma, C4] = Elastic2d_stud(eps, matparam, stateVar)

% Material parameter
xE   = matparam(1);        % Young's modulus
xnu  = matparam(2);        % Poisson ratio

xblk = #TODO   % bulk modulus
xmu =  #TODO     % shear modulus = second Lame parameter

% Dimension of tensors
tdm = 3;
    
% Kronecker delta
I = eye(tdm,tdm);
    
% 4th-order identity tensor
I4 = zeros(tdm,tdm,tdm,tdm);
for i = 1:tdm
    for j = 1:tdm
        for k = 1:tdm
            for l = 1:tdm
                I4(i,j,k,l) = I(i,j)*I(k,l);
            end
        end
    end
end

% 4th-order (sym-) identity tensor
I4sym = zeros(tdm,tdm,tdm,tdm);
for i = 1:tdm
    for j = 1:tdm
        for k = 1:tdm
            for l = 1:tdm
                I4sym(i,j,k,l) = 0.5*( I(i,k)*I(j,l) + I(i,l)*I(j,k) );
            end
        end
    end
end

% 4th-order deviatoric identity tensor
I4dev = zeros(tdm,tdm,tdm,tdm);
for i = 1:tdm
    for j = 1:tdm
        for k = 1:tdm
            for l = 1:tdm
                I4dev(i,j,k,l) = I4sym(i,j,k,l) - 1/3*I4(i,j,k,l);
            end
        end
    end
end


% Volumetric stress
vol_sigma = #TODO

% Deviatoric strains
dev_eps = #TODO

% Trial deviatoric stress
dev_sigma = #TODO


% Elasto-Plastic modulus
C4 = zeros(tdm,tdm,tdm,tdm);
#TODO

% Stress
sigma = #TODO


end